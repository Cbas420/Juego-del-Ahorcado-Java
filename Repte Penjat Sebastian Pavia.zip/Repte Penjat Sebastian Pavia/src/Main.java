public class Main {
    public static void main(String[] args) {
        boolean acierto = true;
        boolean quedanLetras = true;
        String mascaraString;
        String palabra;
        String[] palabras = {
                "manzana", "felicidad", "aventura", "serenidad", "computadora",
                "montaña", "música", "océano", "libertad", "sueño", "café", "exploración",
                "tiempo", "risas", "creatividad", "bosque", "viaje", "silencio", "amistad",
                "color", "escritura", "calma", "esperanza", "bailar", "inspiración",
                "libro", "playa", "sonrisa", "conexión", "aroma" };
        palabra = seleccionPalabra(palabras);
        char[] mascara;
        char[] mascaraAciertos = new char[palabra.length()];
        char intento;
        int vidas = 7;
        seleccionPalabra(palabras);

        System.out.println("Welcome to the Hangman game.");
        System.out.println(dibujo(vidas, acierto) + "\n");
        mascara = mascara(palabra);


        do {
            System.out.println("\nLives: " + vidas);
            System.out.println("Input a letter");
            intento = Teclat.llegirChar();
            acierto = acierto(intento, palabra);
            if (!acierto) {
                vidas--;
            }
            System.out.println(dibujo(vidas, acierto));


            mascaraAciertos(intento, mascara, palabra, mascaraAciertos, acierto);

            quedanLetras = letrasRestantes(mascara);

        } while (vidas > 0 && quedanLetras);
        if (!quedanLetras) {
            System.out.println("\nGanaste!");
        } else if (vidas == 0) {
            System.out.println("\nPerdiste!");
        }
    }

    private static String seleccionPalabra (String[] palabras) {
        String palabraSeleccionada;
        int numero;
        numero = (int) (Math.random() * 30);
        palabraSeleccionada = palabras[numero];
        return palabraSeleccionada;
    }

    private static boolean letrasRestantes (char[] mascara) {
        boolean quedanLetras = true;
        for (int i = 0; i < mascara.length; i++) {
            if (mascara[i] == '_') {
                quedanLetras = true;
                break;
            } else {
                quedanLetras = false;
            }
        }
        return quedanLetras;
    }

    private static char[] mascara (String palabra) {
        char [] mascara = new char [palabra.length()];
        for (int i = 0; i < palabra.length(); i++) {
            mascara[i] = '_';
            System.out.print(mascara[i]);
        }
        return mascara;
    }

    private static void mascaraAciertos (char letra, char[] mascara, String palabra, char[] mascaraAciertos, boolean acierto) {
        for (int i = 0; i < palabra.length(); i++) {
            if (acierto && letra == palabra.charAt(i) && mascara[i] == '_') {
                mascara[i] = letra;
            }
            System.out.print(mascara[i]);
        }
    }

    private static Boolean acierto (char intento, String palabra) {
        boolean acertado = false;
        for (int i = 0; i < palabra.length(); i++) {
            if (intento == palabra.charAt(i)) {
                acertado = true;
                i = palabra.length();
            }
        }
        return acertado;
    }

    private static String dibujo(int vidas, boolean acierto) {
        String dibujos = "Ahorcaste al ahorcado ._.";
        switch (vidas) {
            case 1:
                dibujos = ("""
                           |----------------
                           |               |
                           |               O
                           |              /|\\
                           |              / \\
                           |
                           ------------------
                           """);
                break;
            case 2:
                dibujos = ("""
                           |----------------
                           |               |
                           |               O
                           |              /|\\
                           |                \\
                           |
                           ------------------
                           """);
                break;
            case 3:
                dibujos = ("""
                           |----------------
                           |               |
                           |               O
                           |              /|\\
                           |
                           |
                           ------------------
                           """);
                break;
            case 4:
                dibujos = ("""
                           |----------------
                           |               |
                           |               O
                           |               |\\
                           |
                           |
                           ------------------
                           """);
                break;
            case 5:
                dibujos = ("""
                           |----------------
                           |               |
                           |               O
                           |               |
                           |
                           |
                           ------------------
                           """);
                break;
            case 6:
                dibujos = ("""
                           |----------------
                           |               |
                           |               O
                           |
                           |
                           |
                           ------------------
                           """);
                break;
            case 7:
                dibujos = ("""
                           |----------------
                           |               |
                           |
                           |
                           |
                           |
                           ------------------
                           """);
                break;
        }
        return dibujos;
        }

}
